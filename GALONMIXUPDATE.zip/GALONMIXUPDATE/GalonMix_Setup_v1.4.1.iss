#define MyAppName "GalonMix"
#define MyAppVersion "1.4.1"
#define MyAppPublisher "GalonMix"
#define MyAppExeName "MixConsol.exe"

[Setup]
AppId={{B7D1A1F4-8D41-4D6C-9A6E-1A4B6B9F4141}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\GalonMix
DefaultGroupName=GalonMix
OutputDir=Output
OutputBaseFilename=GalonMix_Setup_v1.4.1
SetupIconFile=UPDATE\Assets\GalonMix.ico
UninstallDisplayIcon={app}\Assets\GalonMix.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64compatible
DisableProgramGroupPage=yes
PrivilegesRequired=admin
VersionInfoVersion={#MyAppVersion}
VersionInfoProductVersion={#MyAppVersion}
VersionInfoProductName={#MyAppName}
VersionInfoDescription=GalonMix Audio Mixer
Uninstallable=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Buat shortcut di Desktop"; GroupDescription: "Shortcut:"; Flags: unchecked

[Files]
Source: "UPDATE\MixConsol.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "UPDATE\Assets\*"; DestDir: "{app}\Assets"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "UPDATE\CARA  DAN PANDUAN INSTAL.txt"; DestDir: "{app}"; Flags: isreadme

[Icons]
Name: "{group}\GalonMix"; Filename: "{app}\MixConsol.exe"; IconFilename: "{app}\Assets\GalonMix.ico"
Name: "{group}\Panduan Instalasi"; Filename: "{app}\CARA  DAN PANDUAN INSTAL.txt"
Name: "{autodesktop}\GalonMix"; Filename: "{app}\MixConsol.exe"; IconFilename: "{app}\Assets\GalonMix.ico"; Tasks: desktopicon

[Run]
Filename: "{app}\MixConsol.exe"; Description: "Jalankan GalonMix"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{app}\Assets"
