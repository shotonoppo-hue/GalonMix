#define MyAppName "GalonMix"
#define MyAppVersion "1.4.0"
#define MyAppPublisher "GALON MIX"
#define MyAppExeName "MixConsol.exe"

[Setup]
AppId={{FAC55419-8D2D-4643-B5AE-518BA5A8D743}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\GalonMix
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=Output
OutputBaseFilename=GalonMix_Setup_v1.4.0
SetupIconFile=GalonMix.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
VersionInfoVersion=1.4.0.0
VersionInfoProductName={#MyAppName}
VersionInfoProductVersion={#MyAppVersion}
VersionInfoCompany={#MyAppPublisher}
; This installer packages the supplied 64-bit application build.

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Buat shortcut di Desktop"; GroupDescription: "Shortcut tambahan:"; Flags: unchecked

[Files]
Source: "MixConsol.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "GalonMix.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "Assets\*"; DestDir: "{app}\Assets"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "CARA  DAN PANDUAN INSTAL.txt"; DestDir: "{app}"; DestName: "Panduan GalonMix.txt"; Flags: ignoreversion

[Icons]
Name: "{group}\GalonMix"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\GalonMix.ico"; WorkingDir: "{app}"
Name: "{autodesktop}\GalonMix"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\GalonMix.ico"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Jalankan GalonMix"; Flags: postinstall nowait skipifsilent
