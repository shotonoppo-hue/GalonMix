﻿#define MyAppName "BEHRINGER_BY_MIDAS8442"
#define MyAppVersion "1.1.0"
#define MyAppPublisher "GALON MIX"
#define MyAppExeName "MixConsol.exe"

[Setup]
AppId={{9DFA73C2-6B9A-4F7B-91E8-4F3A6B844200}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\BEHRINGER_BY_MIDAS8442
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=Output
OutputBaseFilename=BEHRINGER_BY_MIDAS8442_Setup
SetupIconFile=GalonMix.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
WizardSizePercent=100

[Languages]
Name: "indonesian"; MessagesFile: "Indonesian.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Buat shortcut di Desktop"; GroupDescription: "Shortcut:"; Flags: unchecked

[Files]
Source: "App\MixConsol.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "App\Assets\*"; DestDir: "{app}\Assets"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Jalankan {#MyAppName}"; Flags: postinstall nowait skipifsilent
