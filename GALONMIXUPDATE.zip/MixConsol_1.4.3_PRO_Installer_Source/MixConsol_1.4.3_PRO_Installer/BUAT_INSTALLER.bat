@echo off
setlocal
set "ISCC=%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 7\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo Inno Setup Compiler tidak ditemukan.
  echo Instal Inno Setup 6 atau 7, lalu jalankan file ini lagi.
  pause
  exit /b 1
)
"%ISCC%" "%~dp0MixConsol_1.4.3_PRO_Setup.iss"
if errorlevel 1 exit /b 1
echo.
echo Selesai. Periksa folder Output.
pause
