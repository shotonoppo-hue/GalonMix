#define MyAppName "MixConsol"
#define MyAppVersion "1.4.5"
#define MyAppPublisher "MixConsol"
#define MyAppExeName "MixConsol.exe"

[Setup]
AppId={{9B8D6F43-2B7C-4D8A-9C41-7A6E8D3F2B10}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\MixConsol
DefaultGroupName=MixConsol
DisableProgramGroupPage=yes
OutputDir=Output
OutputBaseFilename=MixConsol_Setup_v{#MyAppVersion}_x64
SetupIconFile=update\GalonMix.ico
UninstallDisplayIcon={app}\MixConsol.exe
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
CloseApplications=yes
RestartApplications=no
Uninstallable=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Buat shortcut di Desktop"; GroupDescription: "Shortcut:"; Flags: unchecked

[Files]
Source: "update\MixConsol.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "update\resources.res"; DestDir: "{app}"; Flags: ignoreversion
Source: "update\GalonMix.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "update\Assets\*"; DestDir: "{app}\Assets"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\MixConsol"; Filename: "{app}\MixConsol.exe"; IconFilename: "{app}\GalonMix.ico"
Name: "{autodesktop}\MixConsol"; Filename: "{app}\MixConsol.exe"; IconFilename: "{app}\GalonMix.ico"; Tasks: desktopicon

[Run]
Filename: "{app}\MixConsol.exe"; Description: "Jalankan MixConsol"; Flags: postinstall nowait skipifsilent

[UninstallDelete]
; Preset dan cache pengguna di AppData sengaja TIDAK dihapus.
; Folder instalasi hanya berisi file aplikasi dan aset.
